#The Casino Gambling Game

_This is a casino related number guessing game where the player have to guess the computer's number. If he gets succeeded then the player will win the match else computer will win_